﻿using System;

namespace DefiningClasses
{
    public class Tire
    {
        public double TirePressure { get; set; }
        public int TireAge { get; set; }
    }
}
