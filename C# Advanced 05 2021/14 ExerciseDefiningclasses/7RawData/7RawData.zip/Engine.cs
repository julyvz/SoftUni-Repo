﻿using System;

namespace DefiningClasses
{
    public class Engine
    {
        public int EngineSpeed { get; set; }
        public int EnginePower { get; set; }
    }
}
