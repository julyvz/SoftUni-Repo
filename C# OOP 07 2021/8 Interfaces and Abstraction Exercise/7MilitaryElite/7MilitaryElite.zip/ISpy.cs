﻿namespace _7MilitaryElite
{
    public interface ISpy
    {
        int CodeNumber { get; set; }

        string ToString();
    }
}