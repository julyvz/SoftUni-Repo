﻿using System.Collections.Generic;

namespace _7MilitaryElite
{
    public interface ILieutenantGeneral
    {
        List<Private> Privates { get; set; }
    }
}