﻿namespace _6FoodShortage
{
    interface IIdentifiable
    {
        public string Id { get; set; }
    }
}
