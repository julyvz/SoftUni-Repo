﻿namespace _6FoodShortage
{
   public interface IBitrhable
    {
        public string Birthdate { get; set; }
    }
}
