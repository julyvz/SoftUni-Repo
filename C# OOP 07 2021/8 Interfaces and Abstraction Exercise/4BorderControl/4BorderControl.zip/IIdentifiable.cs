﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4BorderControl
{
    interface IIdentifiable
    {
        public string Id { get; set; }
    }
}
