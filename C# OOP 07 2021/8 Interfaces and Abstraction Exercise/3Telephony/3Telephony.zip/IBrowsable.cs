﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3Telephony
{
    interface IBrowsable
    {
        string Browse(string site);
    }
}
