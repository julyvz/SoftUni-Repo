﻿namespace _5BirthdayCelebrations
{
    interface IIdentifiable
    {
        public string Id { get; set; }
    }
}
