﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _5BirthdayCelebrations
{
    interface IBitrhable
    {
        public string Birthdate { get; set; }
    }
}
