﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3ShoppingSpree
{
   public class Person
    {

        private string name;
        private int money;
        private List<string> bagOfProducts;

        public Person(string name, int money)
        {
            Name = name;
            Money = money;
            bagOfProducts = new List<string>();
        }

        public List<string> BagOfProducts
        {
            get { return bagOfProducts; }
        }

        public string Name
        {
            get { return name; }
            set 
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Name cannot be empty");
                }
                name = value; 
            }
        }

        public int Money
        {
            get { return money; }
            set 
            {
                if (value < 0)
                {
                    throw new ArgumentException("Money cannot be negative");
                }
                money = value;
            }
        }

        public void AddToBag(string prodName)
        {
            bagOfProducts.Add(prodName);
        }
    }
}
