﻿using CarRacing.Models.Cars.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarRacing.Models.Cars
{
    public abstract class Car : ICar
    {
        protected Car(string make, string model, string vIN, int horsePower, double fuelAvailable, double fuelConsumptionPerRace)
        {
            Make = make;
            Model = model;
            VIN = vIN;
            HorsePower = horsePower;
            FuelAvailable = fuelAvailable;
            FuelConsumptionPerRace = fuelConsumptionPerRace;
        }

        public string Make { get; }

        public string Model { get; }

        public string VIN { get; }

        public int HorsePower { get; }

        public double FuelAvailable { get; }

        public double FuelConsumptionPerRace { get; }

        public virtual void Drive() // PP virtual
        {
            throw new NotImplementedException();
        }
    }
}
