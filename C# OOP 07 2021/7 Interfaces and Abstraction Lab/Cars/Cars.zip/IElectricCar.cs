﻿namespace Cars
{
    public interface IElectricCar
    {
        public int Battery { get; set; }
    }
}
