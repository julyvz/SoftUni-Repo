﻿using Easter.Models.Eggs.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Easter.Models.Eggs
{
    public class Egg : IEgg
    {
        public Egg(string name, int energyRequired)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException("Egg name cannot be null or empty.");
            }

            Name = name;
            EnergyRequired = energyRequired;
        }

        public string Name { get; }

        public int EnergyRequired { get; private set; }

        public void GetColored()
        {
            throw new NotImplementedException();
        }

        public bool IsDone()
        {
            throw new NotImplementedException();
        }
    }
}
