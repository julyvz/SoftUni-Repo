﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AquaShop.Models.Decorations
{
    public class Plant : Decoration
    {
        public Plant()
            : base(5, 10.0M)
        {
        }
    }
}
