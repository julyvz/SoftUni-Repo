﻿using AquaShop.Models.Decorations.Contracts;
using AquaShop.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace AquaShop.Repositories
{
    public class DecorationRepository : IRepository<IDecoration>
    {
        private List<IDecoration> models;
        
        public IReadOnlyCollection<IDecoration> Models
        {
            get => models.AsReadOnly();
        }

        public void Add(IDecoration model)
        {
            throw new NotImplementedException();
        }

        public IDecoration FindByType(string type)
        {
            throw new NotImplementedException();
        }

        public bool Remove(IDecoration model)
        {
            throw new NotImplementedException();
        }
    }
}
