﻿using System.Collections.Generic;
using WarCroft.Entities.Items;
using System.Linq;
using System;

namespace WarCroft.Entities.Inventory
{
    public abstract class Bag : IBag
    {
        private List<Item> items;

        protected Bag(int capacity = 100)
        {
            Capacity = capacity;
            items = new List<Item>();
        }

        public int Capacity { get; set; }

        public int Load { get => Items.Sum(i => i.Weight); }

        public IReadOnlyCollection<Item> Items { get => items.AsReadOnly(); }

        public void AddItem(Item item)
        {
            if (Load + item.Weight > Capacity)
            {
                throw new InvalidOperationException("Bag is full!");
            }

            items.Add(item);
        }

        public Item GetItem(string name)
        {
            if (items.Count == 0)
            {
                throw new InvalidOperationException("Bag is empty!");
            }

            // TODO
            return new FirePotion();
        }
    }
}
