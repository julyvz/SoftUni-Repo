﻿using WarCroft.Entities.Characters.Contracts;


namespace WarCroft.Entities.Items
{
    public class FirePotion : Item
    {
        public FirePotion() : base(5)
        {
        }

        public override void AffectCharacter(Character character)
        {
            base.AffectCharacter(character);
            // ToDO The character’s health gets decreased by 20 points. If the character’s health drops to zero, the character dies (IsAlive  false).
        }
    }
}
